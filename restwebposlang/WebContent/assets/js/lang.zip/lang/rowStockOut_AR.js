var getRowStockOutLang = {
		
		qtyCantBeBlank : "الكمية لا يمكن أن يكون فارغا",
}