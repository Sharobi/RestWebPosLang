/* ******** ARABIC LANGUSGE ******** */

var getEDPLang = {
	
	rawItems : "Raw Items",
	edpNotCrtd : "Edp is not created,some error occured!",
	cont1 : "Daily Type For Today's Date Already Exist...",
	cont2 : "Left Over Food Type Estimate For Today's Date Already Exist...",
	plsSelctEDP : "Please select any EDP !",
	plsEntrNewEDPDate : "Please enter new EDP Date !",
	update : "Update",
	plsEntrEDPQty : "EDP quantity can not be blank",
	plsEntrEDPQty1 : "EDP quantity greater than zero "
	
	
	
}
