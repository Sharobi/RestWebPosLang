/* ******** ARABIC LANGUSGE ******** */

var getLangUnpaidOrder = {
	
		sl : "رقم سري",
		name : "اسم",
		orderType : "نوع الطلب",
		qty : "كمية",
		total : "مجموع",
		discount : "خصم",
		rate : "معدل",
		update : "حديث م",
}
