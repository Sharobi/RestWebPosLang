/* ******** ARABIC LANGUSGE ******** */

var getEDPLang = {
	
		rawItems : "عناصر الخام",
		edpNotCrtd : "لم يتم إنشاء EDP، حدث بعض الخطأ!",
		cont1 : "اليومي نوع للتاريخ اليوم موجودة بالفعل ...",
		cont2 : "اليسار على الغذاء النوع تقدير لتاريخ اليوم موجودة بالفعل ...",
		plsSelctEDP : "يرجى تحديد أي EDP!",
		plsEntrNewEDPDate : "الرجاء إدخال EDP جديد التسجيل",
		update : "تحديث",
		plsEntrEDPQty : "EDP ​​الكمية لا يمكن أن يكون فارغا",
		plsEntrEDPQty1 : "EDP ​​كمية أكبر من الصفر",
		
	
}
