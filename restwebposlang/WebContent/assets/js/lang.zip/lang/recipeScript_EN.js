var getReciepeLang = {

		update : "Update",
}