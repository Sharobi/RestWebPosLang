var getReciepeLang = {

		update : "تحديث",
}