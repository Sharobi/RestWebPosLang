/* ******** ARABIC LANGUSGE ******** */

var getLangUnpaidOrder = {

		sl : "SL",
		name : "NAME",
		orderType : "ORDER TYPE",
		qty : "QUANTITY",
		total : "TOTAL",
		discount : "DISCOUNT",
		rate : "RATE",
		update : "UPDATE",
}
