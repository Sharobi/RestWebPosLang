var getInvLang = {
	
		update : "تحديث م",
		
}